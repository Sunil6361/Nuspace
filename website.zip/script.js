/* =========================
   GLOBAL STYLES
========================= */

html{
    scroll-behavior: smooth;
}

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
}

body{
    line-height: 1.6;
    background-color: #ffffff;
}

/* =========================
   HEADER SECTION
========================= */

header{
    background-color: #111;
    color: white;
    padding: 20px 60px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    position: sticky;
    top: 0;
    z-index: 1000;
}

.logo h1{
    font-size: 32px;
}

nav a{
    text-decoration: none;
    color: white;
    margin-left: 20px;
    font-size: 18px;
    transition: 0.3s;
}

nav a:hover{
    color: orange;
}

/* =========================
   WHATSAPP BUTTON SECTION
========================= */

.whatsapp{
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 60px;
    height: 60px;
    background-color: #25D366;
    color: white;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 35px;
    text-decoration: none;
}

/* =========================
   INSTAGRAM BUTTON SECTION
========================= */

.instagram{
    position: fixed;
    bottom: 90px;
    right: 20px;
    width: 60px;
    height: 60px;
    background: #E4405F;
    color: white;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    text-decoration: none;
    font-size: 35px;
}


/* =========================
   HOME / HERO SECTION
========================= */

.hero{
    height: 90vh;

    background-image:
    linear-gradient(rgba(0,0,0,0.6),
    rgba(0,0,0,0.6)),
    url("https://images.unsplash.com/photo-1484154218962-a197022b5858");

    background-size: cover;
    background-position: center;

    display: flex;
    justify-content: center;
    align-items: center;

    text-align: center;
    color: white;
}

.hero-content h2{
    font-size: 55px;
    margin-bottom: 20px;
}

.hero-content p{
    font-size: 22px;
    margin-bottom: 25px;
}

.hero-content button{
    background-color: orange;
    color: white;
    border: none;
    padding: 15px 30px;
    font-size: 18px;
    border-radius: 5px;
    cursor: pointer;
}

.hero-content button:hover{
    background-color: darkorange;
}

/* =========================
   ABOUT SECTION
========================= */

.about{
    padding: 80px 100px;
    text-align: center;
}

.about h2{
    font-size: 40px;
    margin-bottom: 20px;
}

.about p{
    max-width: 900px;
    margin: auto;
    font-size: 18px;
}

/* =========================
   SERVICES SECTION
========================= */

.services{
    background-color: #f5f5f5;
    padding: 80px 50px;
}

.services h2{
    text-align: center;
    font-size: 40px;
    margin-bottom: 40px;
}

.service-container{
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 25px;
}

.card{
    width: 300px;
    background-color: white;
    padding: 30px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
    transition: 0.3s;
}

.card:hover{
    transform: translateY(-10px);
}

.card h3{
    margin-bottom: 15px;
}

/* =========================
   PROJECTS SECTION
========================= */

.projects{
    padding: 80px 50px;
}

.projects h2{
    text-align: center;
    font-size: 40px;
    margin-bottom: 40px;
}

.project-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(250px,1fr));
    gap: 20px;
}

.project-box{
    height: 250px;
    background-color: #ddd;
    border-radius: 10px;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 25px;
    font-weight: bold;
}

.project-box:hover{
    transform: scale(1.03);
    transition: 0.3s;
}

.project-box img{
    width: 100%;
    height: 250px;
    object-fit: cover;
    border-radius: 10px;
}

/* =========================
   CONTACT SECTION
========================= */

.contact{
    background-color: #f5f5f5;
    padding: 80px 50px;
}

.contact h2{
    text-align: center;
    font-size: 40px;
    margin-bottom: 30px;
}

form{
    max-width: 600px;
    margin: auto;
}

input,
textarea{
    width: 100%;
    padding: 15px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

textarea{
    resize: none;
}

form button{
    width: 100%;
    background-color: orange;
    color: white;
    border: none;
    padding: 15px;
    font-size: 18px;
    cursor: pointer;
    border-radius: 5px;
}

form button:hover{
    background-color: darkorange;
}

/* =========================
   GOOGLE MAP SECTION
========================= */

iframe{
    width: 100%;
    height: 400px;
    border-radius: 10px;
    margin-top: 20px;
    border: 0;
}

/* =========================
   FOOTER SECTION
========================= */

footer{
    background-color: #111;
    color: white;
    text-align: center;
    padding: 20px;
}

/* =========================
   RESPONSIVE DESIGN
========================= */

@media(max-width:768px){

    header{
        flex-direction: column;
        text-align: center;
    }

    nav{
        margin-top: 15px;
    }

    nav a{
        display: block;
        margin: 10px 0;
    }

    .hero-content h2{
        font-size: 35px;
    }

    .hero-content p{
        font-size: 18px;
    }

    .about{
        padding: 50px 20px;
    }

    .services,
    .projects,
    .contact{
        padding: 50px 20px;
    }
}